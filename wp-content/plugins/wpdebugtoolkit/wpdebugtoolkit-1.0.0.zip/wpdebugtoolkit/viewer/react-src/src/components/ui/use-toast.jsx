import { useToast as useToastOriginal, ToastProvider } from "./toast";

export { useToastOriginal as useToast, ToastProvider };
